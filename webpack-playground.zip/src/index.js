// import addImage from './add-image';
import HelloWorldButton from './components/hello-world-button';
import Heading from './components/heading';
import JsImage from './components/js-image';

Heading(1, 3);
HelloWorldButton();
// addImage();
JsImage(3, 5);
