import _ from 'lodash';

import './index.scss';

function Heading(a, b) {
  const $h1 = document.createElement('h1');
  const $body = document.querySelector('body');

  $h1.innerHTML = `Webpack is awesome ${_.sum(a, b)}`;
  $body.appendChild($h1);
}

export default Heading;
