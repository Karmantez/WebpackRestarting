import JavaScriptLogo from '../../assets/javascript.png';

import _ from 'lodash';

import './index.scss';

function JsImage(a, b) {
  const $img = document.createElement('img');
  const $body = document.querySelector('body');

  $img.alt = `JavaScript Logo ${_.sum(a, b)}`;
  $img.src = JavaScriptLogo;
  $img.classList.add('js-image');

  $body.appendChild($img);
}

export default JsImage;
