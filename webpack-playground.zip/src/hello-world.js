function helloWorld() {
  console.log('Hello Webpack!!!');
}

export default helloWorld;
