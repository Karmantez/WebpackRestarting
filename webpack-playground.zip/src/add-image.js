import JavaScriptLogo from './assets/javascript.png';
import AltText from './assets/altText.txt';

function addImage() {
  const img = document.createElement('img');
  img.alt = AltText;
  img.width = 300;
  img.src = JavaScriptLogo;

  const body = document.querySelector('body');
  body.appendChild(img);
}

export default addImage;
