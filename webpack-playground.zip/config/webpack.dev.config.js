const paths = require('./paths');
const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
  mode: 'development',
  entry: paths.appIndexJs,
  output: {
    filename: 'bundle.js',
    path: paths.appBuild,
    publicPath: '',
  },
  devServer: {
    port: 3000,
    static: {
      directory: paths.appBuild,
    },
    devMiddleware: {
      index: 'index.html',
      writeToDisk: true,
    },
    hot: true,
    open: true,
  },
  module: {
    rules: [
      {
        test: /\.(ttf)$/,
        type: 'asset/resource',
      },
      {
        test: /\.(png|jpg)$/,
        type: 'asset',
        parser: {
          dataUrlCondition: {
            // 30Kb가 초과될 경우 asset/resource로 변경
            maxSize: 3 * 1024 * 10,
          },
        },
      },
      {
        test: /\.(txt)$/,
        type: 'asset/source',
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'],
      },
      {
        test: /\.scss$/,
        use: ['style-loader', 'css-loader', 'sass-loader'],
      },
      {
        test: /\.js$/,
        exclude: ['/node_modules'],
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/env'],
          },
        },
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      title: 'Webpack Playground',
      filename: 'index.html',
      template: paths.appHtml,
      meta: {
        description: 'Some description',
      },
    }),
  ],
};
