const paths = require('./paths');
const TerserPlugin = require('terser-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
  mode: 'production',
  entry: paths.appIndexJs,
  output: {
    filename: 'bundle.[contenthash:8].js',
    path: paths.appBuild,
    publicPath: 'auto',
    clean: true,
  },
  module: {
    rules: [
      {
        test: /\.(ttf)$/,
        type: 'asset/resource',
      },
      {
        test: /\.(png|jpg)$/,
        type: 'asset',
        parser: {
          dataUrlCondition: {
            // 30Kb가 초과될 경우 asset/resource로 변경
            maxSize: 3 * 1024 * 10,
          },
        },
      },
      {
        test: /\.(txt)$/,
        type: 'asset/source',
      },
      {
        test: /\.css$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader'],
      },
      {
        test: /\.scss$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader', 'sass-loader'],
      },
      {
        test: /\.js$/,
        exclude: ['/node_modules'],
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/env'],
          },
        },
      },
    ],
  },
  plugins: [
    new TerserPlugin(),
    new MiniCssExtractPlugin({
      filename: 'styles.[contenthash:8].css',
    }),
    new HtmlWebpackPlugin({
      title: 'Webpack Playground',
      filename: 'index.html',
      template: paths.appHtml,
      meta: {
        description: 'Some description',
      },
    }),
  ],
  optimization: {
    splitChunks: {
      chunks: 'all',
    },
  },
};
